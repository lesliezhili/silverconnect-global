// lib/providers.ts
export interface Provider {
  id: string;
  name: string;
  serviceCategories: string[];
  postcode: string;
  rating: number;
  available: boolean;
}

// Mock providers for development
export const PROVIDERS: Provider[] = [
  {
    id: '1',
    name: 'Sarah\'s Senior Care',
    serviceCategories: ['cleaning', 'personal care'],
    postcode: '3000',
    rating: 4.8,
    available: true
  },
  {
    id: '2',
    name: 'James Maintenance',
    serviceCategories: ['maintenance', 'gardening'],
    postcode: '3000',
    rating: 4.9,
    available: true
  },
  {
    id: '3',
    name: 'Caring Hands',
    serviceCategories: ['care', 'companionship'],
    postcode: '3000',
    rating: 4.7,
    available: true
  }
];

export function getProvidersByCategory(category: string): Provider[] {
  return PROVIDERS.filter(p => p.serviceCategories.includes(category));
}

export function getProviderById(id: string): Provider | undefined {
  return PROVIDERS.find(p => p.id === id);
}