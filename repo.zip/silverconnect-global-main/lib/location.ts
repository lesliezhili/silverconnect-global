// Victoria inner-east postcode registry
export interface PostcodeInfo {
  postcode: string
  suburb: string
  state: string
  lat: number
  lng: number
  region: string
  goLiveThreshold: number
}

export const VICTORIA_POSTCODES: PostcodeInfo[] = [
  { postcode: '3102', suburb: 'Kew East',          state: 'VIC', lat: -37.8040, lng: 145.0513, region: 'Inner East', goLiveThreshold: 5 },
  { postcode: '3101', suburb: 'Kew',               state: 'VIC', lat: -37.8006, lng: 145.0320, region: 'Inner East', goLiveThreshold: 5 },
  { postcode: '3103', suburb: 'Balwyn',             state: 'VIC', lat: -37.8067, lng: 145.0843, region: 'Inner East', goLiveThreshold: 5 },
  { postcode: '3104', suburb: 'Balwyn North',       state: 'VIC', lat: -37.7906, lng: 145.0888, region: 'Inner East', goLiveThreshold: 5 },
  { postcode: '3122', suburb: 'Hawthorn',           state: 'VIC', lat: -37.8222, lng: 145.0362, region: 'Inner East', goLiveThreshold: 5 },
  { postcode: '3123', suburb: 'Auburn',             state: 'VIC', lat: -37.8293, lng: 145.0510, region: 'Inner East', goLiveThreshold: 5 },
  { postcode: '3124', suburb: 'Camberwell',         state: 'VIC', lat: -37.8363, lng: 145.0600, region: 'Inner East', goLiveThreshold: 5 },
  { postcode: '3125', suburb: 'Burwood',            state: 'VIC', lat: -37.8485, lng: 145.1058, region: 'Inner East', goLiveThreshold: 5 },
  { postcode: '3126', suburb: 'Canterbury',         state: 'VIC', lat: -37.8234, lng: 145.0730, region: 'Inner East', goLiveThreshold: 5 },
  { postcode: '3127', suburb: 'Box Hill South',     state: 'VIC', lat: -37.8200, lng: 145.1260, region: 'Inner East', goLiveThreshold: 5 },
  { postcode: '3128', suburb: 'Box Hill',           state: 'VIC', lat: -37.8197, lng: 145.1200, region: 'Inner East', goLiveThreshold: 5 },
  { postcode: '3130', suburb: 'Nunawading',         state: 'VIC', lat: -37.8175, lng: 145.1760, region: 'Inner East', goLiveThreshold: 5 },
  { postcode: '3131', suburb: 'Ringwood',           state: 'VIC', lat: -37.8114, lng: 145.2270, region: 'East',       goLiveThreshold: 5 },
  { postcode: '3132', suburb: 'Mitcham',            state: 'VIC', lat: -37.8200, lng: 145.1950, region: 'East',       goLiveThreshold: 5 },
  { postcode: '3068', suburb: 'Clifton Hill',       state: 'VIC', lat: -37.7880, lng: 144.9940, region: 'Inner North', goLiveThreshold: 5 },
  { postcode: '3065', suburb: 'Fitzroy',            state: 'VIC', lat: -37.7995, lng: 144.9790, region: 'Inner North', goLiveThreshold: 5 },
  { postcode: '3000', suburb: 'Melbourne CBD',      state: 'VIC', lat: -37.8136, lng: 144.9631, region: 'CBD',        goLiveThreshold: 5 },
  { postcode: '3121', suburb: 'Richmond',           state: 'VIC', lat: -37.8248, lng: 144.9999, region: 'Inner East', goLiveThreshold: 5 },
]

export const DEFAULT_LOCATION: PostcodeInfo = VICTORIA_POSTCODES[0] // 3102 Kew East

export function findByPostcode(postcode: string): PostcodeInfo | undefined {
  return VICTORIA_POSTCODES.find(p => p.postcode === postcode)
}

export function findNearestPostcode(lat: number, lng: number): PostcodeInfo {
  let nearest = DEFAULT_LOCATION
  let minDist = Infinity
  for (const p of VICTORIA_POSTCODES) {
    const dist = Math.sqrt(Math.pow(p.lat - lat, 2) + Math.pow(p.lng - lng, 2))
    if (dist < minDist) { minDist = dist; nearest = p }
  }
  return nearest
}

// Distance in km between two lat/lng points
export function distanceKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371
  const dLat = (lat2 - lat1) * Math.PI / 180
  const dLng = (lng2 - lng1) * Math.PI / 180
  const a = Math.sin(dLat/2)**2 +
    Math.cos(lat1 * Math.PI/180) * Math.cos(lat2 * Math.PI/180) * Math.sin(dLng/2)**2
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
}

export interface LocationState {
  postcode: string
  suburb: string
  state: string
  lat: number
  lng: number
  source: 'gps' | 'postcode' | 'default'
  detected: boolean
}

export function locationFromPostcodeInfo(info: PostcodeInfo, source: LocationState['source']): LocationState {
  return {
    postcode: info.postcode,
    suburb: info.suburb,
    state: info.state,
    lat: info.lat,
    lng: info.lng,
    source,
    detected: source !== 'default',
  }
}
