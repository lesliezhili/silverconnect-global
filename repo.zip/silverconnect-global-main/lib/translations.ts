export const translations = {
  en: {
    // Header
    serviceRegion: 'Service Region',
    support: '24/7 Support',
    emergency: 'Emergency',
    signIn: 'Sign In',
    signOut: 'Sign Out',
    providerDashboard: 'Provider Dashboard',
    
    // Hero
    heroTitle: 'Quality Care for Your Golden Years',
    heroSubtitle: 'Trusted services for seniors in Australia • China • Canada',
    backgroundChecked: '✓ Background-checked',
    support24: '✓ 24/7 Support',
    insuranceIncluded: '✓ Insurance Included',
    
    // Categories
    allServices: 'All Services',
    cleaning: 'Cleaning',
    cooking: 'Cooking',
    gardening: 'Gardening',
    personalCare: 'Personal Care',
    maintenance: 'Maintenance',
    
    // Auth
    signInMode: 'Sign In',
    signUpMode: 'Create Account',
    email: 'Email',
    password: 'Password',
    fullName: 'Full Name',
    phone: 'Phone',
    signInButton: 'Sign In',
    signUpButton: 'Sign Up',
    noAccount: "Don't have an account?",
    haveAccount: 'Already have an account?',
    createAccount: 'Create Account',
    
    // Booking
    bookService: 'Book Service',
    date: 'Date',
    time: 'Time',
    address: 'Address',
    instructions: 'Special Instructions',
    confirmBooking: 'Confirm Booking',
    bookingSuccess: 'Booking confirmed! You will receive an email shortly.',
    priceOnRequest: 'Price on request',
    contactForPricing: 'Contact for pricing',
    fillAllFields: 'Please fill in all required fields',
    
    // Dashboard
    myBookings: 'My Bookings',
    dashboard: 'Dashboard',
    upcomingServices: 'Upcoming Services',
    noBookings: 'No upcoming bookings',
    bookNow: 'Book Now',
    cancel: 'Cancel',
    booking: 'Booking...',
    bookingNotification: 'You will receive a confirmation email once the booking is accepted',
    freeCancellationSupport: 'Free cancellation • 24hr support',
    service: 'Service',
    signInRequired: 'Please sign in to book a service',
    duration: 'Duration',
    specialInstructionsOptional: 'Special Instructions (Optional)',
    noBookingsPrompt: 'Book a service now to get started.',
    
    // New Features
    selectAccountType: 'What type of account would you like?',
    customer: 'Customer',
    customerDescription: 'Browse and book services for your home',
    serviceProvider: 'Service Provider',
    providerDescription: 'Offer your services and earn income',
    back: 'Back',
    loading: 'Loading...',
    bio: 'Bio',
    yearsExperience: 'Years of Experience',
    rateProvider: 'Rate Provider',
    rateCustomer: 'Rate Customer',
    punctuality: 'Punctuality',
    professionalism: 'Professionalism',
    qualityOfWork: 'Quality of Work',
    customerPreparation: 'Customer Preparation',
    homeAccessibility: 'Home Accessibility',
    communication: 'Communication',
    submitFeedback: 'Submit Feedback',
    overallRating: 'Overall Rating',
    comments: 'Comments (Optional)',
    filterByRating: 'Filter by Rating',
    filterByDistance: 'Filter by Distance',
    filterBySpecialty: 'Filter by Specialty',
    noProviders: 'No providers found in your area',
    detectedLocation: 'Detected location',
    browseProviders: '👥 Browse Service Providers',
    findProvidersNearby: 'Find verified providers within 1km of your location',
    hideProviders: 'Hide Providers',
    showProviders: 'Browse Providers',
    ratingLabel: '⭐ By Rating',
    distanceLabel: '📍 By Distance',
    specialtyLabel: '🎯 By Specialty',
  },
  zh: {
    // Header
    serviceRegion: '服务地区',
    support: '24小时支持',
    emergency: '紧急',
    signIn: '登录',
    signOut: '退出登录',
    providerDashboard: '服务商控制面板',
    
    // Hero
    heroTitle: '为您的黄金年代提供优质照护',
    heroSubtitle: '为澳大利亚、中国、加拿大的老年人提供可信赖的服务',
    backgroundChecked: '✓ 背景调查',
    support24: '✓ 24小时支持',
    insuranceIncluded: '✓ 包含保险',
    
    // Categories
    allServices: '全部服务',
    cleaning: '清洁服务',
    cooking: '烹饪服务',
    gardening: '园艺服务',
    personalCare: '个人护理',
    maintenance: '维修维护',
    
    // Auth
    signInMode: '登录',
    signUpMode: '创建账户',
    email: '邮箱',
    password: '密码',
    fullName: '全名',
    phone: '电话',
    signInButton: '登录',
    signUpButton: '注册',
    noAccount: '还没有账户？',
    haveAccount: '已有账户？',
    createAccount: '创建账户',
    
    // Booking
    bookService: '预订服务',
    date: '日期',
    time: '时间',
    address: '地址',
    instructions: '特殊要求',
    confirmBooking: '确认预订',
    bookingSuccess: '预订成功！您将收到一封确认邮件。',
    priceOnRequest: '价格面议',
    contactForPricing: '联系询价',
    fillAllFields: '请填写所有必填字段',
    
    // Dashboard
    myBookings: '我的预订',
    dashboard: '仪表板',
    upcomingServices: '即将到来的服务',
    noBookings: '暂无预订',
    bookNow: '立即预订',
    cancel: '取消',
    booking: '预订中...',
    bookingNotification: '预订一经接受，您将收到确认邮件',
    freeCancellationSupport: '免费取消 • 24小时支持',
    service: '服务',
    signInRequired: '请先登录以预订服务',
    duration: '时长',
    specialInstructionsOptional: '特殊说明（可选）',
    noBookingsPrompt: '现在预订服务以开始使用。',
    
    // New Features
    selectAccountType: '您想要创建哪种类型的账户?',
    customer: '客户',
    customerDescription: '浏览并预订家庭服务',
    serviceProvider: '服务提供商',
    providerDescription: '提供您的服务并赚取收入',
    back: '返回',
    loading: '加载中...',
    bio: '个人简介',
    yearsExperience: '工作年限',
    rateProvider: '评价服务商',
    rateCustomer: '评价客户',
    punctuality: '准时性',
    professionalism: '专业性',
    qualityOfWork: '工作质量',
    customerPreparation: '客户准备',
    homeAccessibility: '家庭可达性',
    communication: '沟通能力',
    submitFeedback: '提交反馈',
    overallRating: '总体评分',
    comments: '评论（可选）',
    filterByRating: '按评分筛选',
    filterByDistance: '按距离筛选',
    filterBySpecialty: '按专业筛选',
    noProviders: '您所在地区找不到提供商',
    detectedLocation: '检测到的位置',
    browseProviders: '👥 浏览服务提供商',
    findProvidersNearby: '在您附近1公里内寻找经过验证的服务提供商',
    hideProviders: '隐藏提供商',
    showProviders: '浏览提供商',
    ratingLabel: '⭐ 按评分',
    distanceLabel: '📍 按距离',
    specialtyLabel: '🎯 按专业',
  }
};

export type Language = 'en' | 'zh';

export function getLanguage(country: 'AU' | 'CN' | 'CA'): Language {
  return country === 'CN' ? 'zh' : 'en';
}

export function t(key: string, lang: Language): string {
  const keys = key.split('.');
  let value: any = translations[lang];
  
  for (const k of keys) {
    value = value?.[k];
  }
  
  if (!value) {
    return translations.en[key as keyof typeof translations.en] || key;
  }
  
  return value;
}
