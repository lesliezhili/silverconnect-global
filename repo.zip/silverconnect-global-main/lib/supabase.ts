import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

const isMissingEnv = !supabaseUrl || !supabaseAnonKey ||
  supabaseUrl.includes('placeholder') || supabaseAnonKey.includes('placeholder')

if (isMissingEnv && typeof window !== 'undefined') {
  console.warn(
    '[SilverConnect] Running in demo mode — Supabase not connected.\n' +
    'Add real credentials to .env.local to enable live database.'
  )
}

// Safe fallback — never throws, all DB calls fail gracefully
export const supabase = createClient(
  supabaseUrl ?? 'https://placeholder.supabase.co',
  supabaseAnonKey ?? 'placeholder-anon-key',
  { auth: { persistSession: false, autoRefreshToken: false } }
)

export const isSupabaseConfigured = !isMissingEnv
