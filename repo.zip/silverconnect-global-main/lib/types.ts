// lib/types.ts

// Service categories
export type ServiceCategory = 
  | 'cleaning'
  | 'gardening'
  | 'personal-care'
  | 'maintenance'
  | 'companionship'
  | 'shopping'
  | 'transport'
  | 'nursing'
  | 'meal-prep'
  | 'emergency';

// Funding options for seniors (Australian context)
export const FUNDING_OPTIONS = {
  HCP: 'Home Care Package',
  CHSP: 'Commonwealth Home Support Programme',
  PRIVATE: 'Private Payment',
  DVA: 'Department of Veterans\' Affairs',
  NDIS: 'NDIS (for under 65)',
  STCA: 'Short-Term Restorative Care',
  TRANSITION: 'Transition Care Programme'
} as const;

export type FundingOption = keyof typeof FUNDING_OPTIONS;

// Service interface
export interface Service {
  id: string;
  name: string;
  category: ServiceCategory;
  description: string;
  duration: number; // in minutes
  basePrice: number;
  taxRate: number;
  requiresAssessment: boolean;
  popularForSeniors: boolean;
}

// Booking interface
export interface Booking {
  id: string;
  serviceId: string;
  seniorId: string;
  providerId: string;
  date: string;
  time: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  amount: number;
  fundingSource: FundingOption;
  emergencyContact: {
    name: string;
    phone: string;
    relationship: string;
  };
  specialInstructions?: string;
  createdAt: string;
}

// Senior/User interface
export interface Senior {
  id: string;
  name: string;
  email: string;
  phone: string;
  dateOfBirth: string;
  postcode: string;
  fundingPackage?: string;
  emergencyContact: {
    name: string;
    phone: string;
    relationship: string;
  };
  medicalConditions?: string[];
  preferredLanguage: 'en' | 'zh' | 'fr';
  createdAt: string;
}

// Provider interface
export interface Provider {
  id: string;
  name: string;
  abn: string;
  services: ServiceCategory[];
  postcodes: string[];
  rating: number;
  verified: boolean;
  languages: string[];
  phone: string;
  email: string;
}

// Country configuration
export interface CountryConfig {
  code: 'AU' | 'CN' | 'CA';
  name: string;
  currency: string;
  currencySymbol: string;
  taxRate: number;
  taxName: string;
  emergencyNumber: string;
  language: string;
}

// Location types for Victoria, Australia
export interface Location {
  postcode: string;
  suburb: string;
  state: string;
  country: string;
  lat: number;
  lng: number;
}

// Assessment required for certain services
export interface Assessment {
  id: string;
  seniorId: string;
  serviceId: string;
  date: string;
  assessor: string;
  recommendations: string[];
  approved: boolean;
  notes: string;
}

// Review/Rating interface
export interface Review {
  id: string;
  bookingId: string;
  seniorId: string;
  providerId: string;
  rating: number;
  comment: string;
  date: string;
  verified: boolean;
}

// Helper functions
export function formatCurrency(amount: number, countryCode: 'AU' | 'CN' | 'CA'): string {
  const symbols = { AU: 'A$', CN: '¥', CA: 'C$' };
  return `${symbols[countryCode]}${amount.toFixed(2)}`;
}

export function calculateTax(amount: number, taxRate: number): number {
  return amount * (taxRate / 100);
}

export function getTotalWithTax(amount: number, taxRate: number): number {
  return amount + calculateTax(amount, taxRate);
}

// Senior-friendly service recommendations based on common needs
export const SENIOR_SERVICES = {
  cleaning: {
    name: 'Home Cleaning',
    description: 'Light housekeeping, vacuuming, dusting, and bathroom cleaning',
    seniorFriendly: true
  },
  'personal-care': {
    name: 'Personal Care',
    description: 'Bathing, dressing, grooming, and toileting assistance',
    seniorFriendly: true
  },
  companionship: {
    name: 'Social Support',
    description: 'Friendly visits, conversation, and social activities',
    seniorFriendly: true
  },
  'meal-prep': {
    name: 'Meal Preparation',
    description: 'Nutritious meal planning and cooking',
    seniorFriendly: true
  },
  transport: {
    name: 'Transport',
    description: 'Medical appointments, shopping, and social outings',
    seniorFriendly: true
  }
};

// Emergency alert levels
export enum EmergencyLevel {
  LOW = 'low',
  MEDIUM = 'medium',
  HIGH = 'high',
  CRITICAL = 'critical'
}

// Notification preferences
export interface NotificationPreferences {
  sms: boolean;
  email: boolean;
  emergencyAlerts: boolean;
  appointmentReminders: boolean;
  familyUpdates: boolean;
}