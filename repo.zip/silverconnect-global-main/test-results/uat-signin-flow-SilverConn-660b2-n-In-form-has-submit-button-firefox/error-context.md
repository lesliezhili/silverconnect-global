# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: uat-signin-flow.spec.ts >> SilverConnect Global - Sign-In UAT >> UAT-007: Sign In form has submit button
- Location: e2e/uat-signin-flow.spec.ts:106:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('button').filter({ hasText: /Sign In|Login|Submit/i })
Expected: visible
Error: strict mode violation: locator('button').filter({ hasText: /Sign In|Login|Submit/i }) resolved to 2 elements:
    1) <button class="bg-green-600 text-white px-6 py-2 rounded-full hover:bg-green-700 transition">Sign In</button> aka getByRole('banner').getByRole('button', { name: 'Sign In' })
    2) <button class="w-full bg-green-600 text-white py-2 rounded-lg font-medium hover:bg-green-700 disabled:bg-gray-400 transition">Sign In</button> aka getByRole('button', { name: 'Sign In' }).nth(1)

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for locator('button').filter({ hasText: /Sign In|Login|Submit/i })

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e2]:
    - banner [ref=e3]:
      - generic [ref=e5]:
        - generic [ref=e6]:
          - generic [ref=e8]: SC
          - generic [ref=e9]:
            - generic [ref=e10]:
              - heading "SilverConnect" [level=1] [ref=e11]
              - generic [ref=e12]: 🇦🇺 AU
            - paragraph [ref=e13]:
              - text: "🌍 Service Region:"
              - generic [ref=e14]: Australia • AUD
        - generic [ref=e15]:
          - link "24/7 Support" [ref=e16] [cursor=pointer]:
            - /url: /support
            - img [ref=e17]
            - generic [ref=e19]: 24/7 Support
          - link "Emergency" [ref=e20] [cursor=pointer]:
            - /url: /emergency
            - img [ref=e21]
            - generic [ref=e23]: Emergency
        - generic [ref=e24]:
          - button [ref=e25]:
            - img [ref=e26]
          - button "Sign In" [active] [ref=e29]
    - generic [ref=e32]:
      - generic [ref=e33]:
        - generic [ref=e34]: "Service Region:"
        - generic [ref=e35]:
          - button "🇦🇺 Australia" [ref=e36]:
            - generic [ref=e37]: 🇦🇺
            - generic [ref=e38]: Australia
            - img [ref=e39]
          - button "🇨🇳 China" [ref=e41]:
            - generic [ref=e42]: 🇨🇳
            - generic [ref=e43]: China
          - button "🇨🇦 Canada" [ref=e44]:
            - generic [ref=e45]: 🇨🇦
            - generic [ref=e46]: Canada
      - generic [ref=e47]: 💡 Prices shown include local taxes
    - generic [ref=e49]:
      - heading "Quality Care for Your Golden Years" [level=1] [ref=e50]
      - paragraph [ref=e51]: Trusted services for seniors in Australia • China • Canada
      - generic [ref=e52]:
        - generic [ref=e53]: ✓ Background-checked
        - generic [ref=e54]: ✓ 24/7 Support
        - generic [ref=e55]: ✓ Insurance Included
    - generic [ref=e58]:
      - generic [ref=e59]:
        - heading "👥 Browse Service Providers" [level=2] [ref=e60]
        - paragraph [ref=e61]: Find verified providers within 1km of your location
      - button "Browse Providers" [ref=e62]:
        - img [ref=e63]
        - text: Browse Providers
    - button "🤖 AI Help" [ref=e65]:
      - generic [ref=e66]:
        - generic [ref=e67]: 🤖
        - generic [ref=e68]: AI Help
    - generic [ref=e70]:
      - generic [ref=e71]:
        - heading "Sign In" [level=2] [ref=e72]
        - button [ref=e73]:
          - img [ref=e74]
      - generic [ref=e77]:
        - generic [ref=e78]:
          - generic [ref=e79]:
            - img [ref=e80]
            - text: Email
          - textbox "your@email.com" [ref=e83]
        - generic [ref=e84]:
          - generic [ref=e85]:
            - img [ref=e86]
            - text: Password
          - textbox "••••••••" [ref=e89]
        - button "Sign In" [ref=e90]
        - button "Don't have an account? Create Account" [ref=e91]
  - button "Open Next.js Dev Tools" [ref=e97] [cursor=pointer]:
    - img [ref=e98]
  - alert [ref=e102]
```

# Test source

```ts
  16  |     await page.goto('http://localhost:3000');
  17  |     
  18  |     // Wait for page to load
  19  |     await page.waitForLoadState('networkidle');
  20  |   });
  21  | 
  22  |   test('UAT-001: Homepage loads successfully', async ({ page }) => {
  23  |     // Verify page title and main elements
  24  |     await expect(page).toHaveTitle(/SilverConnect|Senior Care/i);
  25  |     
  26  |     // Verify header is visible
  27  |     const header = page.locator('header');
  28  |     await expect(header).toBeVisible();
  29  |     
  30  |     // Verify hero section
  31  |     const heroSection = page.locator('section').first();
  32  |     await expect(heroSection).toBeVisible();
  33  |   });
  34  | 
  35  |   test('UAT-002: Sign In button is visible and clickable', async ({ page }) => {
  36  |     // Find Sign In button
  37  |     const signInButton = page.locator('button, a').filter({ hasText: /Sign In|sign in/i });
  38  |     
  39  |     // Verify button exists and is visible
  40  |     await expect(signInButton).toBeVisible();
  41  |     await expect(signInButton).toBeEnabled();
  42  |   });
  43  | 
  44  |   test('UAT-003: Clicking Sign In opens authentication modal', async ({ page }) => {
  45  |     // Click Sign In button
  46  |     const signInButton = page.locator('button, a').filter({ hasText: /Sign In|sign in/i });
  47  |     await signInButton.click();
  48  |     
  49  |     // Wait for modal to appear
  50  |     await page.waitForTimeout(500);
  51  |     
  52  |     // Verify modal/dialog is visible
  53  |     const modal = page.locator('[role="dialog"]');
  54  |     await expect(modal).toBeVisible();
  55  |   });
  56  | 
  57  |   test('UAT-004: Sign In modal contains email and password fields', async ({ page }) => {
  58  |     // Click Sign In button
  59  |     const signInButton = page.locator('button, a').filter({ hasText: /Sign In|sign in/i });
  60  |     await signInButton.click();
  61  |     
  62  |     // Wait for modal
  63  |     await page.waitForTimeout(500);
  64  |     
  65  |     // Verify email input field
  66  |     const emailInput = page.locator('input[type="email"], input[placeholder*="email" i]');
  67  |     await expect(emailInput).toBeVisible();
  68  |     
  69  |     // Verify password input field
  70  |     const passwordInput = page.locator('input[type="password"]');
  71  |     await expect(passwordInput).toBeVisible();
  72  |   });
  73  | 
  74  |   test('UAT-005: User can enter email in sign-in form', async ({ page }) => {
  75  |     // Click Sign In button
  76  |     const signInButton = page.locator('button, a').filter({ hasText: /Sign In|sign in/i });
  77  |     await signInButton.click();
  78  |     
  79  |     // Wait for modal
  80  |     await page.waitForTimeout(500);
  81  |     
  82  |     // Fill email field
  83  |     const emailInput = page.locator('input[type="email"], input[placeholder*="email" i]');
  84  |     await emailInput.fill('test@example.com');
  85  |     
  86  |     // Verify email was entered
  87  |     await expect(emailInput).toHaveValue('test@example.com');
  88  |   });
  89  | 
  90  |   test('UAT-006: User can enter password in sign-in form', async ({ page }) => {
  91  |     // Click Sign In button
  92  |     const signInButton = page.locator('button, a').filter({ hasText: /Sign In|sign in/i });
  93  |     await signInButton.click();
  94  |     
  95  |     // Wait for modal
  96  |     await page.waitForTimeout(500);
  97  |     
  98  |     // Fill password field
  99  |     const passwordInput = page.locator('input[type="password"]');
  100 |     await passwordInput.fill('TestPassword123!');
  101 |     
  102 |     // Verify password was entered (input type=password hides value, but we can check focus)
  103 |     await expect(passwordInput).toBeFocused();
  104 |   });
  105 | 
  106 |   test('UAT-007: Sign In form has submit button', async ({ page }) => {
  107 |     // Click Sign In button
  108 |     const signInButton = page.locator('button, a').filter({ hasText: /Sign In|sign in/i });
  109 |     await signInButton.click();
  110 |     
  111 |     // Wait for modal
  112 |     await page.waitForTimeout(500);
  113 |     
  114 |     // Find submit/login button
  115 |     const submitButton = page.locator('button').filter({ hasText: /Sign In|Login|Submit/i });
> 116 |     await expect(submitButton).toBeVisible();
      |                                ^ Error: expect(locator).toBeVisible() failed
  117 |     await expect(submitButton).toBeEnabled();
  118 |   });
  119 | 
  120 |   test('UAT-008: Complete sign-in form with valid inputs', async ({ page }) => {
  121 |     // Click Sign In button
  122 |     const signInButton = page.locator('button, a').filter({ hasText: /Sign In|sign in/i });
  123 |     await signInButton.click();
  124 |     
  125 |     // Wait for modal
  126 |     await page.waitForTimeout(500);
  127 |     
  128 |     // Fill form fields
  129 |     const emailInput = page.locator('input[type="email"], input[placeholder*="email" i]');
  130 |     const passwordInput = page.locator('input[type="password"]');
  131 |     
  132 |     await emailInput.fill('test@example.com');
  133 |     await passwordInput.fill('TestPassword123!');
  134 |     
  135 |     // Find and click submit button
  136 |     const submitButton = page.locator('button').filter({ hasText: /Sign In|Login|Submit/i });
  137 |     
  138 |     // Verify form is filled and ready to submit
  139 |     await expect(emailInput).toHaveValue('test@example.com');
  140 |     await expect(submitButton).toBeEnabled();
  141 |   });
  142 | 
  143 |   test('UAT-009: Sign In modal has close button', async ({ page }) => {
  144 |     // Click Sign In button
  145 |     const signInButton = page.locator('button, a').filter({ hasText: /Sign In|sign in/i });
  146 |     await signInButton.click();
  147 |     
  148 |     // Wait for modal
  149 |     await page.waitForTimeout(500);
  150 |     
  151 |     // Find close button (X button or Cancel)
  152 |     const closeButton = page.locator('button[aria-label*="close" i], button[aria-label*="dismiss" i], button').filter({ hasText: /Close|Cancel|×/i }).first();
  153 |     
  154 |     // Verify close button exists and is clickable
  155 |     if (await closeButton.isVisible()) {
  156 |       await expect(closeButton).toBeEnabled();
  157 |     }
  158 |   });
  159 | 
  160 |   test('UAT-010: Homepage displays country selector', async ({ page }) => {
  161 |     // Look for country selector on homepage
  162 |     const countrySelector = page.locator('select, button').filter({ 
  163 |       hasText: /Country|Australia|Canada|China/i 
  164 |     });
  165 |     
  166 |     // Verify country selector is visible
  167 |     if (await countrySelector.isVisible()) {
  168 |       await expect(countrySelector).toBeVisible();
  169 |     }
  170 |   });
  171 | 
  172 |   test('UAT-011: Page performance - Homepage loads within 3 seconds', async ({ page }) => {
  173 |     const startTime = Date.now();
  174 |     
  175 |     await page.goto('http://localhost:3000');
  176 |     await page.waitForLoadState('networkidle');
  177 |     
  178 |     const loadTime = Date.now() - startTime;
  179 |     
  180 |     // Verify page loaded within 3 seconds
  181 |     expect(loadTime).toBeLessThan(3000);
  182 |     console.log(`✅ Homepage loaded in ${loadTime}ms`);
  183 |   });
  184 | 
  185 |   test('UAT-012: Mobile responsiveness - Sign In works on mobile viewport', async ({ page }) => {
  186 |     // Set mobile viewport
  187 |     await page.setViewportSize({ width: 375, height: 667 });
  188 |     
  189 |     // Navigate to homepage
  190 |     await page.goto('http://localhost:3000');
  191 |     await page.waitForLoadState('networkidle');
  192 |     
  193 |     // Click Sign In button (should work on mobile)
  194 |     const signInButton = page.locator('button, a').filter({ hasText: /Sign In|sign in/i });
  195 |     await expect(signInButton).toBeVisible();
  196 |     await signInButton.click();
  197 |     
  198 |     // Verify modal appears on mobile
  199 |     await page.waitForTimeout(500);
  200 |     const modal = page.locator('[role="dialog"]');
  201 |     await expect(modal).toBeVisible();
  202 |   });
  203 | });
  204 | 
  205 | test.describe('SilverConnect Global - Sign-Up UAT', () => {
  206 |   test.beforeEach(async ({ page }) => {
  207 |     // Navigate to homepage
  208 |     await page.goto('http://localhost:3000');
  209 |     
  210 |     // Wait for page to load
  211 |     await page.waitForLoadState('networkidle');
  212 |   });
  213 | 
  214 |   test('UAT-013: Sign Up button is visible and clickable', async ({ page }) => {
  215 |     // Find Sign Up button
  216 |     const signUpButton = page.locator('button, a').filter({ hasText: /Sign Up|sign up|Register|register/i });
```