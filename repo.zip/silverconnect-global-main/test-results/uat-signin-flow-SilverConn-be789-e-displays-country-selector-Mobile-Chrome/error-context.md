# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: uat-signin-flow.spec.ts >> SilverConnect Global - Sign-In UAT >> UAT-010: Homepage displays country selector
- Location: e2e/uat-signin-flow.spec.ts:160:7

# Error details

```
Error: locator.isVisible: Error: strict mode violation: locator('select, button').filter({ hasText: /Country|Australia|Canada|China/i }) resolved to 3 elements:
    1) <button class="px-4 py-2 rounded-full transition-all flex items-center gap-2 bg-green-600 text-white shadow-md">…</button> aka getByRole('button', { name: '🇦🇺 Australia' })
    2) <button class="px-4 py-2 rounded-full transition-all flex items-center gap-2 bg-gray-100 text-gray-700 hover:bg-gray-200">…</button> aka getByRole('button', { name: '🇨🇳 China' })
    3) <button class="px-4 py-2 rounded-full transition-all flex items-center gap-2 bg-gray-100 text-gray-700 hover:bg-gray-200">…</button> aka getByRole('button', { name: '🇨🇦 Canada' })

Call log:
    - checking visibility of locator('select, button').filter({ hasText: /Country|Australia|Canada|China/i })

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - banner [ref=e3]:
      - generic [ref=e5]:
        - generic [ref=e6]:
          - generic [ref=e8]: SC
          - generic [ref=e9]:
            - generic [ref=e10]:
              - heading "SilverConnect" [level=1] [ref=e11]
              - generic [ref=e12]: 🇦🇺 AU
            - paragraph [ref=e13]:
              - text: "🌍 Service Region:"
              - generic [ref=e14]: Australia • AUD
        - generic [ref=e15]:
          - button [ref=e16]:
            - img [ref=e17]
          - button "Sign In" [ref=e20]
    - generic [ref=e23]:
      - generic [ref=e24]:
        - generic [ref=e25]: "Service Region:"
        - generic [ref=e26]:
          - button "🇦🇺 Australia" [ref=e27]:
            - generic [ref=e28]: 🇦🇺
            - generic [ref=e29]: Australia
            - img [ref=e30]
          - button "🇨🇳 China" [ref=e32]:
            - generic [ref=e33]: 🇨🇳
            - generic [ref=e34]: China
          - button "🇨🇦 Canada" [ref=e35]:
            - generic [ref=e36]: 🇨🇦
            - generic [ref=e37]: Canada
      - generic [ref=e38]: 💡 Prices shown include local taxes
    - generic [ref=e40]:
      - heading "Quality Care for Your Golden Years" [level=1] [ref=e41]
      - paragraph [ref=e42]: Trusted services for seniors in Australia • China • Canada
      - generic [ref=e43]:
        - generic [ref=e44]: ✓ Background-checked
        - generic [ref=e45]: ✓ 24/7 Support
        - generic [ref=e46]: ✓ Insurance Included
    - generic [ref=e49]:
      - generic [ref=e50]:
        - heading "👥 Browse Service Providers" [level=2] [ref=e51]
        - paragraph [ref=e52]: Find verified providers within 1km of your location
      - button "Browse Providers" [ref=e53]:
        - img [ref=e54]
        - text: Browse Providers
    - button "🤖" [ref=e56]:
      - generic [ref=e58]: 🤖
  - button "Open Next.js Dev Tools" [ref=e64] [cursor=pointer]:
    - img [ref=e65]
  - alert [ref=e68]
```

# Test source

```ts
  67  |     await expect(emailInput).toBeVisible();
  68  |     
  69  |     // Verify password input field
  70  |     const passwordInput = page.locator('input[type="password"]');
  71  |     await expect(passwordInput).toBeVisible();
  72  |   });
  73  | 
  74  |   test('UAT-005: User can enter email in sign-in form', async ({ page }) => {
  75  |     // Click Sign In button
  76  |     const signInButton = page.locator('button, a').filter({ hasText: /Sign In|sign in/i });
  77  |     await signInButton.click();
  78  |     
  79  |     // Wait for modal
  80  |     await page.waitForTimeout(500);
  81  |     
  82  |     // Fill email field
  83  |     const emailInput = page.locator('input[type="email"], input[placeholder*="email" i]');
  84  |     await emailInput.fill('test@example.com');
  85  |     
  86  |     // Verify email was entered
  87  |     await expect(emailInput).toHaveValue('test@example.com');
  88  |   });
  89  | 
  90  |   test('UAT-006: User can enter password in sign-in form', async ({ page }) => {
  91  |     // Click Sign In button
  92  |     const signInButton = page.locator('button, a').filter({ hasText: /Sign In|sign in/i });
  93  |     await signInButton.click();
  94  |     
  95  |     // Wait for modal
  96  |     await page.waitForTimeout(500);
  97  |     
  98  |     // Fill password field
  99  |     const passwordInput = page.locator('input[type="password"]');
  100 |     await passwordInput.fill('TestPassword123!');
  101 |     
  102 |     // Verify password was entered (input type=password hides value, but we can check focus)
  103 |     await expect(passwordInput).toBeFocused();
  104 |   });
  105 | 
  106 |   test('UAT-007: Sign In form has submit button', async ({ page }) => {
  107 |     // Click Sign In button
  108 |     const signInButton = page.locator('button, a').filter({ hasText: /Sign In|sign in/i });
  109 |     await signInButton.click();
  110 |     
  111 |     // Wait for modal
  112 |     await page.waitForTimeout(500);
  113 |     
  114 |     // Find submit/login button
  115 |     const submitButton = page.locator('button').filter({ hasText: /Sign In|Login|Submit/i });
  116 |     await expect(submitButton).toBeVisible();
  117 |     await expect(submitButton).toBeEnabled();
  118 |   });
  119 | 
  120 |   test('UAT-008: Complete sign-in form with valid inputs', async ({ page }) => {
  121 |     // Click Sign In button
  122 |     const signInButton = page.locator('button, a').filter({ hasText: /Sign In|sign in/i });
  123 |     await signInButton.click();
  124 |     
  125 |     // Wait for modal
  126 |     await page.waitForTimeout(500);
  127 |     
  128 |     // Fill form fields
  129 |     const emailInput = page.locator('input[type="email"], input[placeholder*="email" i]');
  130 |     const passwordInput = page.locator('input[type="password"]');
  131 |     
  132 |     await emailInput.fill('test@example.com');
  133 |     await passwordInput.fill('TestPassword123!');
  134 |     
  135 |     // Find and click submit button
  136 |     const submitButton = page.locator('button').filter({ hasText: /Sign In|Login|Submit/i });
  137 |     
  138 |     // Verify form is filled and ready to submit
  139 |     await expect(emailInput).toHaveValue('test@example.com');
  140 |     await expect(submitButton).toBeEnabled();
  141 |   });
  142 | 
  143 |   test('UAT-009: Sign In modal has close button', async ({ page }) => {
  144 |     // Click Sign In button
  145 |     const signInButton = page.locator('button, a').filter({ hasText: /Sign In|sign in/i });
  146 |     await signInButton.click();
  147 |     
  148 |     // Wait for modal
  149 |     await page.waitForTimeout(500);
  150 |     
  151 |     // Find close button (X button or Cancel)
  152 |     const closeButton = page.locator('button[aria-label*="close" i], button[aria-label*="dismiss" i], button').filter({ hasText: /Close|Cancel|×/i }).first();
  153 |     
  154 |     // Verify close button exists and is clickable
  155 |     if (await closeButton.isVisible()) {
  156 |       await expect(closeButton).toBeEnabled();
  157 |     }
  158 |   });
  159 | 
  160 |   test('UAT-010: Homepage displays country selector', async ({ page }) => {
  161 |     // Look for country selector on homepage
  162 |     const countrySelector = page.locator('select, button').filter({ 
  163 |       hasText: /Country|Australia|Canada|China/i 
  164 |     });
  165 |     
  166 |     // Verify country selector is visible
> 167 |     if (await countrySelector.isVisible()) {
      |                               ^ Error: locator.isVisible: Error: strict mode violation: locator('select, button').filter({ hasText: /Country|Australia|Canada|China/i }) resolved to 3 elements:
  168 |       await expect(countrySelector).toBeVisible();
  169 |     }
  170 |   });
  171 | 
  172 |   test('UAT-011: Page performance - Homepage loads within 3 seconds', async ({ page }) => {
  173 |     const startTime = Date.now();
  174 |     
  175 |     await page.goto('http://localhost:3000');
  176 |     await page.waitForLoadState('networkidle');
  177 |     
  178 |     const loadTime = Date.now() - startTime;
  179 |     
  180 |     // Verify page loaded within 3 seconds
  181 |     expect(loadTime).toBeLessThan(3000);
  182 |     console.log(`✅ Homepage loaded in ${loadTime}ms`);
  183 |   });
  184 | 
  185 |   test('UAT-012: Mobile responsiveness - Sign In works on mobile viewport', async ({ page }) => {
  186 |     // Set mobile viewport
  187 |     await page.setViewportSize({ width: 375, height: 667 });
  188 |     
  189 |     // Navigate to homepage
  190 |     await page.goto('http://localhost:3000');
  191 |     await page.waitForLoadState('networkidle');
  192 |     
  193 |     // Click Sign In button (should work on mobile)
  194 |     const signInButton = page.locator('button, a').filter({ hasText: /Sign In|sign in/i });
  195 |     await expect(signInButton).toBeVisible();
  196 |     await signInButton.click();
  197 |     
  198 |     // Verify modal appears on mobile
  199 |     await page.waitForTimeout(500);
  200 |     const modal = page.locator('[role="dialog"]');
  201 |     await expect(modal).toBeVisible();
  202 |   });
  203 | });
  204 | 
  205 | test.describe('SilverConnect Global - Sign-Up UAT', () => {
  206 |   test.beforeEach(async ({ page }) => {
  207 |     // Navigate to homepage
  208 |     await page.goto('http://localhost:3000');
  209 |     
  210 |     // Wait for page to load
  211 |     await page.waitForLoadState('networkidle');
  212 |   });
  213 | 
  214 |   test('UAT-013: Sign Up button is visible and clickable', async ({ page }) => {
  215 |     // Find Sign Up button
  216 |     const signUpButton = page.locator('button, a').filter({ hasText: /Sign Up|sign up|Register|register/i });
  217 |     
  218 |     // Verify button exists and is visible
  219 |     if (await signUpButton.isVisible()) {
  220 |       await expect(signUpButton).toBeVisible();
  221 |       await expect(signUpButton).toBeEnabled();
  222 |     }
  223 |   });
  224 | 
  225 |   test('UAT-014: Clicking Sign Up opens authentication modal', async ({ page }) => {
  226 |     // Find and click Sign Up button
  227 |     const signUpButton = page.locator('button, a').filter({ hasText: /Sign Up|sign up|Register|register/i });
  228 |     
  229 |     if (await signUpButton.isVisible()) {
  230 |       await signUpButton.click();
  231 |       
  232 |       // Wait for modal to appear
  233 |       await page.waitForTimeout(500);
  234 |       
  235 |       // Verify modal/dialog is visible
  236 |       const modal = page.locator('[role="dialog"]');
  237 |       await expect(modal).toBeVisible();
  238 |     }
  239 |   });
  240 | 
  241 |   test('UAT-015: Sign Up modal contains email and password fields', async ({ page }) => {
  242 |     // Find and click Sign Up button
  243 |     const signUpButton = page.locator('button, a').filter({ hasText: /Sign Up|sign up|Register|register/i });
  244 |     
  245 |     if (await signUpButton.isVisible()) {
  246 |       await signUpButton.click();
  247 |       
  248 |       // Wait for modal
  249 |       await page.waitForTimeout(500);
  250 |       
  251 |       // Verify email input field
  252 |       const emailInput = page.locator('input[type="email"], input[placeholder*="email" i]');
  253 |       if (await emailInput.isVisible()) {
  254 |         await expect(emailInput).toBeVisible();
  255 |       }
  256 |       
  257 |       // Verify password input field
  258 |       const passwordInput = page.locator('input[type="password"]');
  259 |       if (await passwordInput.isVisible()) {
  260 |         await expect(passwordInput).toBeVisible();
  261 |       }
  262 |     }
  263 |   });
  264 | 
  265 |   test('UAT-016: User can enter email in sign-up form', async ({ page }) => {
  266 |     // Find and click Sign Up button
  267 |     const signUpButton = page.locator('button, a').filter({ hasText: /Sign Up|sign up|Register|register/i });
```