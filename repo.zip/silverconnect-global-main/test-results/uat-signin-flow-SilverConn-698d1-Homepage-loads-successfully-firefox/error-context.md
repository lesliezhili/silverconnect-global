# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: uat-signin-flow.spec.ts >> SilverConnect Global - Sign-In UAT >> UAT-001: Homepage loads successfully
- Location: e2e/uat-signin-flow.spec.ts:22:7

# Error details

```
Error: expect(page).toHaveTitle(expected) failed

Expected pattern: /SilverConnect|Senior Care/i
Received string:  "Create Next App"
Timeout: 5000ms

Call log:
  - Expect "toHaveTitle" with timeout 5000ms
    9 × unexpected value "Create Next App"

```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - banner [ref=e3]:
      - generic [ref=e5]:
        - generic [ref=e6]:
          - generic [ref=e8]: SC
          - generic [ref=e9]:
            - generic [ref=e10]:
              - heading "SilverConnect" [level=1] [ref=e11]
              - generic [ref=e12]: 🇦🇺 AU
            - paragraph [ref=e13]:
              - text: "🌍 Service Region:"
              - generic [ref=e14]: Australia • AUD
        - generic [ref=e15]:
          - link "24/7 Support" [ref=e16] [cursor=pointer]:
            - /url: /support
            - img [ref=e17]
            - generic [ref=e19]: 24/7 Support
          - link "Emergency" [ref=e20] [cursor=pointer]:
            - /url: /emergency
            - img [ref=e21]
            - generic [ref=e23]: Emergency
        - generic [ref=e24]:
          - button [ref=e25]:
            - img [ref=e26]
          - button "Sign In" [ref=e29]
    - generic [ref=e32]:
      - generic [ref=e33]:
        - generic [ref=e34]: "Service Region:"
        - generic [ref=e35]:
          - button "🇦🇺 Australia" [ref=e36]:
            - generic [ref=e37]: 🇦🇺
            - generic [ref=e38]: Australia
            - img [ref=e39]
          - button "🇨🇳 China" [ref=e41]:
            - generic [ref=e42]: 🇨🇳
            - generic [ref=e43]: China
          - button "🇨🇦 Canada" [ref=e44]:
            - generic [ref=e45]: 🇨🇦
            - generic [ref=e46]: Canada
      - generic [ref=e47]: 💡 Prices shown include local taxes
    - generic [ref=e49]:
      - heading "Quality Care for Your Golden Years" [level=1] [ref=e50]
      - paragraph [ref=e51]: Trusted services for seniors in Australia • China • Canada
      - generic [ref=e52]:
        - generic [ref=e53]: ✓ Background-checked
        - generic [ref=e54]: ✓ 24/7 Support
        - generic [ref=e55]: ✓ Insurance Included
    - generic [ref=e58]:
      - generic [ref=e59]:
        - heading "👥 Browse Service Providers" [level=2] [ref=e60]
        - paragraph [ref=e61]: Find verified providers within 1km of your location
      - button "Browse Providers" [ref=e62]:
        - img [ref=e63]
        - text: Browse Providers
    - button "🤖 AI Help" [ref=e65]:
      - generic [ref=e66]:
        - generic [ref=e67]: 🤖
        - generic [ref=e68]: AI Help
  - button "Open Next.js Dev Tools" [ref=e74] [cursor=pointer]:
    - img [ref=e75]
  - alert [ref=e79]
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | 
  3   | /**
  4   |  * User Acceptance Test (UAT) - Authentication Flow
  5   |  * Tests critical paths:
  6   |  *   - Sign-In: Homepage → Click Sign In → Verify Modal (12 tests)
  7   |  *   - Sign-Up: Homepage → Click Sign Up → Verify Modal (10 tests)
  8   |  *   - Multi-Browser: Run auth flows across all configured browsers
  9   |  * 
  10  |  * Total: 22 automated UAT scenarios
  11  |  */
  12  | 
  13  | test.describe('SilverConnect Global - Sign-In UAT', () => {
  14  |   test.beforeEach(async ({ page }) => {
  15  |     // Navigate to homepage
  16  |     await page.goto('http://localhost:3000');
  17  |     
  18  |     // Wait for page to load
  19  |     await page.waitForLoadState('networkidle');
  20  |   });
  21  | 
  22  |   test('UAT-001: Homepage loads successfully', async ({ page }) => {
  23  |     // Verify page title and main elements
> 24  |     await expect(page).toHaveTitle(/SilverConnect|Senior Care/i);
      |                        ^ Error: expect(page).toHaveTitle(expected) failed
  25  |     
  26  |     // Verify header is visible
  27  |     const header = page.locator('header');
  28  |     await expect(header).toBeVisible();
  29  |     
  30  |     // Verify hero section
  31  |     const heroSection = page.locator('section').first();
  32  |     await expect(heroSection).toBeVisible();
  33  |   });
  34  | 
  35  |   test('UAT-002: Sign In button is visible and clickable', async ({ page }) => {
  36  |     // Find Sign In button
  37  |     const signInButton = page.locator('button, a').filter({ hasText: /Sign In|sign in/i });
  38  |     
  39  |     // Verify button exists and is visible
  40  |     await expect(signInButton).toBeVisible();
  41  |     await expect(signInButton).toBeEnabled();
  42  |   });
  43  | 
  44  |   test('UAT-003: Clicking Sign In opens authentication modal', async ({ page }) => {
  45  |     // Click Sign In button
  46  |     const signInButton = page.locator('button, a').filter({ hasText: /Sign In|sign in/i });
  47  |     await signInButton.click();
  48  |     
  49  |     // Wait for modal to appear
  50  |     await page.waitForTimeout(500);
  51  |     
  52  |     // Verify modal/dialog is visible
  53  |     const modal = page.locator('[role="dialog"]');
  54  |     await expect(modal).toBeVisible();
  55  |   });
  56  | 
  57  |   test('UAT-004: Sign In modal contains email and password fields', async ({ page }) => {
  58  |     // Click Sign In button
  59  |     const signInButton = page.locator('button, a').filter({ hasText: /Sign In|sign in/i });
  60  |     await signInButton.click();
  61  |     
  62  |     // Wait for modal
  63  |     await page.waitForTimeout(500);
  64  |     
  65  |     // Verify email input field
  66  |     const emailInput = page.locator('input[type="email"], input[placeholder*="email" i]');
  67  |     await expect(emailInput).toBeVisible();
  68  |     
  69  |     // Verify password input field
  70  |     const passwordInput = page.locator('input[type="password"]');
  71  |     await expect(passwordInput).toBeVisible();
  72  |   });
  73  | 
  74  |   test('UAT-005: User can enter email in sign-in form', async ({ page }) => {
  75  |     // Click Sign In button
  76  |     const signInButton = page.locator('button, a').filter({ hasText: /Sign In|sign in/i });
  77  |     await signInButton.click();
  78  |     
  79  |     // Wait for modal
  80  |     await page.waitForTimeout(500);
  81  |     
  82  |     // Fill email field
  83  |     const emailInput = page.locator('input[type="email"], input[placeholder*="email" i]');
  84  |     await emailInput.fill('test@example.com');
  85  |     
  86  |     // Verify email was entered
  87  |     await expect(emailInput).toHaveValue('test@example.com');
  88  |   });
  89  | 
  90  |   test('UAT-006: User can enter password in sign-in form', async ({ page }) => {
  91  |     // Click Sign In button
  92  |     const signInButton = page.locator('button, a').filter({ hasText: /Sign In|sign in/i });
  93  |     await signInButton.click();
  94  |     
  95  |     // Wait for modal
  96  |     await page.waitForTimeout(500);
  97  |     
  98  |     // Fill password field
  99  |     const passwordInput = page.locator('input[type="password"]');
  100 |     await passwordInput.fill('TestPassword123!');
  101 |     
  102 |     // Verify password was entered (input type=password hides value, but we can check focus)
  103 |     await expect(passwordInput).toBeFocused();
  104 |   });
  105 | 
  106 |   test('UAT-007: Sign In form has submit button', async ({ page }) => {
  107 |     // Click Sign In button
  108 |     const signInButton = page.locator('button, a').filter({ hasText: /Sign In|sign in/i });
  109 |     await signInButton.click();
  110 |     
  111 |     // Wait for modal
  112 |     await page.waitForTimeout(500);
  113 |     
  114 |     // Find submit/login button
  115 |     const submitButton = page.locator('button').filter({ hasText: /Sign In|Login|Submit/i });
  116 |     await expect(submitButton).toBeVisible();
  117 |     await expect(submitButton).toBeEnabled();
  118 |   });
  119 | 
  120 |   test('UAT-008: Complete sign-in form with valid inputs', async ({ page }) => {
  121 |     // Click Sign In button
  122 |     const signInButton = page.locator('button, a').filter({ hasText: /Sign In|sign in/i });
  123 |     await signInButton.click();
  124 |     
```