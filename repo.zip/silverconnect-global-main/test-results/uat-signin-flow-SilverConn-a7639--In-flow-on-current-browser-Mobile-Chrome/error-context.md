# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: uat-signin-flow.spec.ts >> SilverConnect Global - Multi-Browser UAT >> UAT-BROWSER-SIGNIN: Sign In flow on current browser
- Location: e2e/uat-signin-flow.spec.ts:414:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('[role="dialog"]')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for locator('[role="dialog"]')

```

# Page snapshot

```yaml
- generic [ref=e1]:
  - generic [ref=e2]:
    - banner [ref=e3]:
      - generic [ref=e5]:
        - generic [ref=e6]:
          - generic [ref=e8]: SC
          - generic [ref=e9]:
            - generic [ref=e10]:
              - heading "SilverConnect" [level=1] [ref=e11]
              - generic [ref=e12]: 🇦🇺 AU
            - paragraph [ref=e13]:
              - text: "🌍 Service Region:"
              - generic [ref=e14]: Australia • AUD
        - generic [ref=e15]:
          - button [ref=e16]:
            - img [ref=e17]
          - button "Sign In" [active] [ref=e20]
    - generic [ref=e23]:
      - generic [ref=e24]:
        - generic [ref=e25]: "Service Region:"
        - generic [ref=e26]:
          - button "🇦🇺 Australia" [ref=e27]:
            - generic [ref=e28]: 🇦🇺
            - generic [ref=e29]: Australia
            - img [ref=e30]
          - button "🇨🇳 China" [ref=e32]:
            - generic [ref=e33]: 🇨🇳
            - generic [ref=e34]: China
          - button "🇨🇦 Canada" [ref=e35]:
            - generic [ref=e36]: 🇨🇦
            - generic [ref=e37]: Canada
      - generic [ref=e38]: 💡 Prices shown include local taxes
    - generic [ref=e40]:
      - heading "Quality Care for Your Golden Years" [level=1] [ref=e41]
      - paragraph [ref=e42]: Trusted services for seniors in Australia • China • Canada
      - generic [ref=e43]:
        - generic [ref=e44]: ✓ Background-checked
        - generic [ref=e45]: ✓ 24/7 Support
        - generic [ref=e46]: ✓ Insurance Included
    - generic [ref=e49]:
      - generic [ref=e50]:
        - heading "👥 Browse Service Providers" [level=2] [ref=e51]
        - paragraph [ref=e52]: Find verified providers within 1km of your location
      - button "Browse Providers" [ref=e53]:
        - img [ref=e54]
        - text: Browse Providers
    - button "🤖" [ref=e56]:
      - generic [ref=e58]: 🤖
    - generic [ref=e60]:
      - generic [ref=e61]:
        - heading "Sign In" [level=2] [ref=e62]
        - button [ref=e63]:
          - img [ref=e64]
      - generic [ref=e67]:
        - generic [ref=e68]:
          - generic [ref=e69]:
            - img [ref=e70]
            - text: Email
          - textbox "your@email.com" [ref=e73]
        - generic [ref=e74]:
          - generic [ref=e75]:
            - img [ref=e76]
            - text: Password
          - textbox "••••••••" [ref=e79]
        - button "Sign In" [ref=e80]
        - button "Don't have an account? Create Account" [ref=e81]
  - button "Open Next.js Dev Tools" [ref=e87] [cursor=pointer]:
    - img [ref=e88]
  - alert [ref=e91]
```

# Test source

```ts
  330 |       
  331 |       // Fill form fields
  332 |       const emailInput = page.locator('input[type="email"], input[placeholder*="email" i]').first();
  333 |       const passwordInput = page.locator('input[type="password"]').first();
  334 |       
  335 |       if (await emailInput.isVisible()) {
  336 |         await emailInput.fill('newuser@example.com');
  337 |       }
  338 |       
  339 |       if (await passwordInput.isVisible()) {
  340 |         await passwordInput.fill('SecurePassword123!');
  341 |       }
  342 |       
  343 |       // Verify form is filled
  344 |       if (await emailInput.isVisible()) {
  345 |         await expect(emailInput).toHaveValue('newuser@example.com');
  346 |       }
  347 |     }
  348 |   });
  349 | 
  350 |   test('UAT-020: Sign Up modal has close button', async ({ page }) => {
  351 |     // Find and click Sign Up button
  352 |     const signUpButton = page.locator('button, a').filter({ hasText: /Sign Up|sign up|Register|register/i });
  353 |     
  354 |     if (await signUpButton.isVisible()) {
  355 |       await signUpButton.click();
  356 |       
  357 |       // Wait for modal
  358 |       await page.waitForTimeout(500);
  359 |       
  360 |       // Find close button
  361 |       const closeButton = page.locator('button[aria-label*="close" i], button[aria-label*="dismiss" i], button').filter({ hasText: /Close|Cancel|×/i }).first();
  362 |       
  363 |       if (await closeButton.isVisible()) {
  364 |         await expect(closeButton).toBeEnabled();
  365 |       }
  366 |     }
  367 |   });
  368 | 
  369 |   test('UAT-021: Sign Up form accepts different password strengths', async ({ page }) => {
  370 |     // Find and click Sign Up button
  371 |     const signUpButton = page.locator('button, a').filter({ hasText: /Sign Up|sign up|Register|register/i });
  372 |     
  373 |     if (await signUpButton.isVisible()) {
  374 |       await signUpButton.click();
  375 |       
  376 |       // Wait for modal
  377 |       await page.waitForTimeout(500);
  378 |       
  379 |       // Test password input with various strengths
  380 |       const passwordInput = page.locator('input[type="password"]').first();
  381 |       if (await passwordInput.isVisible()) {
  382 |         await passwordInput.fill('P@ssw0rd!2024');
  383 |         await expect(passwordInput).toHaveValue('P@ssw0rd!2024');
  384 |       }
  385 |     }
  386 |   });
  387 | 
  388 |   test('UAT-022: Mobile responsiveness - Sign Up works on mobile viewport', async ({ page }) => {
  389 |     // Set mobile viewport
  390 |     await page.setViewportSize({ width: 375, height: 667 });
  391 |     
  392 |     // Navigate to homepage
  393 |     await page.goto('http://localhost:3000');
  394 |     await page.waitForLoadState('networkidle');
  395 |     
  396 |     // Find and click Sign Up button (should work on mobile)
  397 |     const signUpButton = page.locator('button, a').filter({ hasText: /Sign Up|sign up|Register|register/i });
  398 |     
  399 |     if (await signUpButton.isVisible()) {
  400 |       await expect(signUpButton).toBeVisible();
  401 |       await signUpButton.click();
  402 |       
  403 |       // Verify modal appears on mobile
  404 |       await page.waitForTimeout(500);
  405 |       const modal = page.locator('[role="dialog"]');
  406 |       await expect(modal).toBeVisible();
  407 |     }
  408 |   });
  409 | });
  410 | 
  411 | test.describe('SilverConnect Global - Multi-Browser UAT', () => {
  412 |   // Run specific tests across all configured browsers
  413 |   
  414 |   test('UAT-BROWSER-SIGNIN: Sign In flow on current browser', async ({ page, browserName }) => {
  415 |     console.log(`🔄 Testing Sign In on ${browserName}...`);
  416 |     
  417 |     // Navigate to homepage
  418 |     await page.goto('http://localhost:3000');
  419 |     await page.waitForLoadState('networkidle');
  420 |     
  421 |     // Click Sign In
  422 |     const signInButton = page.locator('button, a').filter({ hasText: /Sign In|sign in/i });
  423 |     await signInButton.click();
  424 |     
  425 |     // Wait for modal
  426 |     await page.waitForTimeout(500);
  427 |     
  428 |     // Verify modal
  429 |     const modal = page.locator('[role="dialog"]');
> 430 |     await expect(modal).toBeVisible();
      |                         ^ Error: expect(locator).toBeVisible() failed
  431 |     
  432 |     console.log(`✅ Sign In works on ${browserName}`);
  433 |   });
  434 | 
  435 |   test('UAT-BROWSER-SIGNUP: Sign Up flow on current browser', async ({ page, browserName }) => {
  436 |     console.log(`🔄 Testing Sign Up on ${browserName}...`);
  437 |     
  438 |     // Navigate to homepage
  439 |     await page.goto('http://localhost:3000');
  440 |     await page.waitForLoadState('networkidle');
  441 |     
  442 |     // Find Sign Up button
  443 |     const signUpButton = page.locator('button, a').filter({ hasText: /Sign Up|sign up|Register|register/i });
  444 |     
  445 |     if (await signUpButton.isVisible()) {
  446 |       await signUpButton.click();
  447 |       
  448 |       // Wait for modal
  449 |       await page.waitForTimeout(500);
  450 |       
  451 |       // Verify modal
  452 |       const modal = page.locator('[role="dialog"]');
  453 |       await expect(modal).toBeVisible();
  454 |       
  455 |       console.log(`✅ Sign Up works on ${browserName}`);
  456 |     } else {
  457 |       console.log(`⚠️  Sign Up button not visible on ${browserName}`);
  458 |     }
  459 |   });
  460 | });
  461 | 
```