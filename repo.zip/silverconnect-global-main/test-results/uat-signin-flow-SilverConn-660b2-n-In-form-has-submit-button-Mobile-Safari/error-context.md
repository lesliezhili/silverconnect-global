# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: uat-signin-flow.spec.ts >> SilverConnect Global - Sign-In UAT >> UAT-007: Sign In form has submit button
- Location: e2e/uat-signin-flow.spec.ts:106:7

# Error details

```
Error: browserType.launch: Executable doesn't exist at /Users/zhili/Library/Caches/ms-playwright/webkit-2272/pw_run.sh
╔════════════════════════════════════════════════════════════╗
║ Looks like Playwright was just installed or updated.       ║
║ Please run the following command to download new browsers: ║
║                                                            ║
║     npx playwright install                                 ║
║                                                            ║
║ <3 Playwright Team                                         ║
╚════════════════════════════════════════════════════════════╝
```